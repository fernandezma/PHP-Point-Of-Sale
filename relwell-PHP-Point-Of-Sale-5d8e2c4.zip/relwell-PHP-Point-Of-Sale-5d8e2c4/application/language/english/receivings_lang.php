<?php
$lang['recvs_register']='Items Receiving';
$lang['recvs_mode']='Receiving Mode';
$lang['recvs_receiving']='Receive';
$lang['recvs_return']='Return';
$lang['recvs_total']='Total';
$lang['recvs_cost']='Cost';
$lang['recvs_quantity']='Qty.';
$lang['recvs_discount']='Disc %';
$lang['recvs_edit']='Edit';
$lang['recvs_new_supplier'] = 'New Supplier';
$lang['recvs_supplier'] = 'Supplier';
$lang['recvs_select_supplier']='Select Supplier (Optional)';
$lang['recvs_start_typing_supplier_name']='Start Typing supplier\'s name...';
$lang['recvs_unable_to_add_item']='Unable to add item to receiving';
$lang['recvs_error_editing_item']='Error editing item';
$lang['recvs_receipt']='Receivings Receipt';
$lang['recvs_complete_receiving']='Finish';
$lang['recvs_confirm_finish_receiving'] = 'Are you sure you want to submit this receiving? This cannot be undone.';
$lang['recvs_confirm_cancel_receiving'] = 'Are you sure you want to clear this receiving? All items will cleared.';
$lang['recvs_find_or_scan_item']='Find/Scan Item';
$lang['recvs_find_or_scan_item_or_receipt']='Find/Scan Item OR Receipt';
$lang['recvs_id']='Receiving ID';
$lang['recvs_item_name'] = 'Item Name';
$lang['receivings_transaction_failed'] = 'Receivings Transactions Failed';
?>