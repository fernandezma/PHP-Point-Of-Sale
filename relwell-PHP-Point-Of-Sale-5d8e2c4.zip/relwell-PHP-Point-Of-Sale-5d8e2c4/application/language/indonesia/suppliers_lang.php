<?php
$lang['suppliers_new']='Pemasok Baru';
$lang['suppliers_supplier']='Pemasok';
$lang['suppliers_update']='Update Pemasok';
$lang['suppliers_confirm_delete']='Apakah Anda yakin ingin menghapus pemasok yang dipilih?';
$lang['suppliers_none_selected']='Anda belum memilih pemasok untuk menghapus';
$lang['suppliers_error_adding_updating'] = 'Error menambah / memperbarui pemasok';
$lang['suppliers_successful_adding']='Anda telah berhasil menambahkan pemasok';
$lang['suppliers_successful_updating']='Anda telah berhasil memperbarui pemasok';
$lang['suppliers_successful_deleted']='Anda telah berhasil menghapus pemasok';
$lang['suppliers_one_or_multiple']='pemasok';
$lang['suppliers_cannot_be_deleted']='Tidak bisa dihapus pemasok yang dipilih, satu atau lebih dari pemasok yang dipilih memiliki penjualan.';
$lang['suppliers_basic_information']='Informasi Pemasok ';
$lang['suppliers_account_number']='Nomor Akun';
$lang['suppliers_company_name']='Company Name';
$lang['suppliers_company_name_required'] = 'Company Name is a required field';
?>