INSERT INTO `phppos_modules` (`name_lang_key`, `desc_lang_key`, `sort`, `module_id`) 
VALUES ('module_mailchimp', 'module_mailchimp_desc', 91, 'mailchimpdash');
INSERT INTO `phppos_permissions` (`module_id`, `person_id`) VALUES ('mailchimpdash', '1');